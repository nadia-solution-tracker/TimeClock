﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Excel = Microsoft.Office.Interop.Excel;

namespace AttendenceSystem
{
    /// <summary>
    /// Interaction logic for Search.xaml
    /// </summary>
    public partial class Search : Window
    {
        public Search()
        {
            InitializeComponent();
            FillDataGrid();
            PopulateComboBoxFN();

        }




        private void FillDataGrid()
        {
            string ConString = ConfigurationManager.ConnectionStrings["AttendenceEntities"].ConnectionString;
            string CmdString = string.Empty;
            using (SqlConnection con = new SqlConnection(ConString))
            {


                CmdString = "SELECT fname as FirstName,lname as LastName,designation as Designation,password as Password,FORMAT(CAST(MIn AS DATETIME),'hh:mm tt')  as Morning_Start,FORMAT(CAST(MOut AS DATETIME),'hh:mm tt') as Morning_End,FORMAT(CAST(EIn AS DATETIME),'h:mm tt')  as Evening_Start,FORMAT(CAST(EOut AS DATETIME),'h:mm tt')  as Evening_End  FROM staff";
                SqlCommand cmd = new SqlCommand(CmdString, con);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable("staff");
                sda.Fill(dt);
                dataGrid.ItemsSource = dt.DefaultView;
                dataGrid.ColumnWidth = 110;

                dataGrid.RowBackground = Brushes.AliceBlue;
            }
        }

        private static string stringConn = ConfigurationManager.ConnectionStrings["AttendenceEntities"].ConnectionString;

        public string CmdString { get; private set; }

        private void btnfilter_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                string ConString = ConfigurationManager.ConnectionStrings["AttendenceEntities"].ConnectionString;
                string Cmdstring = string.Empty;
                string cmdstring2 = string.Empty;
                using (SqlConnection con = new SqlConnection(ConString))
                {
                    dataGrid.AutoGenerateColumns = true;
                    CmdString = "select pi.fname as FirstName,pi.lname as LastName,convert(varchar(10), pi.date, 120) as Date,FORMAT(CAST(pi.MIn AS DATETIME),'hh:mm') as Morning_Start,FORMAT(CAST(po.MOut AS DATETIME),'hh:mm') as Morning_End,FORMAT(CAST(pi.EIn AS DATETIME),'hh:mm') as Evening_Start,FORMAT(CAST(po.EOut AS DATETIME),'hh:mm') as Evening_End,DATEDIFF(Minute,pi.MIn,po.MOut)/60 as Mrng_Hours, DATEDIFF(Minute,pi.MIn,po.MOut) % 60 as Mrng_Mins,DATEDIFF(Minute,pi.EIn,po.EOut)/60 as Evng_Hour,DATEDIFF(Minute, pi.EIn,po.EOut) % 60 as Evng_Mins,DATEDIFF(Minute,pi.MIn,po.MOut)/60+DATEDIFF(Minute,pi.EIn,po.EOut)/60 AS Total_Hour,DATEDIFF(Minute,pi.MIn,po.MOut)%60+DATEDIFF(Minute,pi.EIn,po.EOut)%60 AS Total_Mins from [punch-In] as pi  JOIN [punch-Out] as po  ON pi.fname=po.fname AND pi.lname=po.lname AND pi.date=po.date WHERE pi.date BETWEEN '" + dpstart.Text + "'AND'" + dpend.Text + "' AND pi.fname='" + combofname.SelectedValue + "' AND pi.lname='" + combolname.SelectedValue + "'";

                    SqlCommand cmd = new SqlCommand(CmdString, con);
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable("punch-In");
                    sda.Fill(dt);
                    dataGrid.ItemsSource = dt.DefaultView;

                    DataView dv = (DataView)dataGrid.ItemsSource;
                    DataRowCollection drc = dv.Table.Rows;
                    IEnumerator rowEnum = drc.GetEnumerator();
                    int sum = 0;
                    int summ = 0;
                    int h = 0;
                    while (rowEnum.MoveNext())
                    {
                        sum += (int)((DataRow)rowEnum.Current)[11];
                        summ += (int)((DataRow)rowEnum.Current)[12];//assuming the 'Total' column has index 3.
                    }
                    h = summ / 60;
                    int fh = 0;
                    fh = sum + h;
                    int fm = 0;
                    fm = summ-h*60;
                    lblhour.Content = "Total Hour/Minutes= " + fh.ToString(CultureInfo.InvariantCulture) + ':' + fm.ToString(CultureInfo.InvariantCulture);

                    lblfilter.Content = "You have selected record for" + ' ' + combofname.SelectedValue + ' ' + combolname.SelectedValue + ' ' + "from" + ' ' + dpstart.Text + ' ' + "to" + ' ' + dpend.Text;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }



        private void PopulateComboBoxFN()
        {

            using (SqlConnection sqlconn = new SqlConnection(stringConn))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = "SELECT fname FROM staff";
                    cmd.Connection = sqlconn;
                    sqlconn.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            this.combofname.Items.Add((string)reader[0]);
                        }
                    }
                    sqlconn.Close();
                }
            }
        }



        private void combofname_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {
            if (this.combofname.SelectedIndex > -1)
            {
                this.combolname.Items.Clear();
                string name = combofname.SelectedItem.ToString();

                using (SqlConnection sqlconn = new SqlConnection(stringConn))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.CommandText = "SELECT lname FROM staff WHERE fname= @fName";
                        cmd.Parameters.Add("@fName", SqlDbType.VarChar, 50).Value = name;
                        cmd.Connection = sqlconn;
                        sqlconn.Open();
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                this.combolname.Items.Add((string)reader[0]);

                            }
                            combolname.SelectedIndex = 0;
                        }

                        sqlconn.Close();

                    }
                }
            }
        }

        private void combolname_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {
            var item = combolname.SelectedItem as staff;
        }

        private void btnpre_Click(object sender, RoutedEventArgs e)
        {
            Admin pre = new Admin();
            pre.Show();
            this.Close();
        }

        private void OnDataGridPrinting(object sender, RoutedEventArgs e)
        {
            System.Windows.Controls.PrintDialog Printdlg = new System.Windows.Controls.PrintDialog();
            if ((bool)Printdlg.ShowDialog().GetValueOrDefault())
            {
                Size pageSize = new Size(Printdlg.PrintableAreaWidth, Printdlg.PrintableAreaHeight);
                // sizing of the element.
                dataGrid.Measure(pageSize);
                dataGrid.Arrange(new Rect(5, 5, pageSize.Width, pageSize.Height));
                Printdlg.PrintVisual(dataGrid, Title);
            }
        }

        private void btnlogout_Click(object sender, RoutedEventArgs e)
        {
            AdminLogin ad = new AdminLogin();
            ad.Show();
            this.Close();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Microsoft.Office.Interop.Excel.Application excel = new Microsoft.Office.Interop.Excel.Application();
                excel.Visible = true;
                Microsoft.Office.Interop.Excel.Workbook workbook = excel.Workbooks.Add(System.Reflection.Missing.Value);
                Microsoft.Office.Interop.Excel.Worksheet sheet1 = (Microsoft.Office.Interop.Excel.Worksheet)workbook.Sheets[1];
                int StartCol = 1;
                int StartRow = 1;
                int j = 0, i = 0;

                //Write Headers
                for (j =0; j < dataGrid.Columns.Count; j++)
                {
                    Microsoft.Office.Interop.Excel.Range myRange = (Microsoft.Office.Interop.Excel.Range)sheet1.Cells[StartRow, StartCol+j];
                    sheet1.Cells[StartRow, StartCol + j].Font.Bold = true;
                    sheet1.Cells[StartCol + j].ColumnWidth = 10;
                    myRange.Value2 = dataGrid.Columns[j].Header;
                }

                StartRow++;

                //Write datagridview content
                for (i = 0; i < dataGrid.Columns.Count; i++)
                {
                    for (j = 0; j < dataGrid.Items.Count; j++)
                    {
                        try
                        {
                            TextBlock b = dataGrid.Columns[i].GetCellContent(dataGrid.Items[j]) as TextBlock;
                            Microsoft.Office.Interop.Excel.Range myRange = (Microsoft.Office.Interop.Excel.Range)sheet1.Cells[StartRow + j, StartCol + i];
                            myRange.Value2 = b.Text;
                        }
                        catch
                        {
                            ;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                lblabsence.Content = "Absent On:";
                DataSet ds1 = new DataSet();


                string ConString = ConfigurationManager.ConnectionStrings["AttendenceEntities"].ConnectionString;
                string CmdString = string.Empty;
                using (SqlConnection con = new SqlConnection(ConString))
                {
                    con.Open();
                    using (SqlCommand command = new SqlCommand("select date from [punch-In] where fname='" + combofname.Text + "' AND lname='" + combolname.Text + "' AND date BETWEEN '" + dpstart.Text + "'AND'" + dpend.Text + "'", con))

                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))

                    {

                        adapter.Fill(ds1);
                        if (ds1.Tables[0].Rows.Count > 0)
                        {

                            int day = dpstart.SelectedDate.Value.Day;
                            int day2 = dpend.SelectedDate.Value.Day;

                            using (SqlCommand command1 = new SqlCommand("SELECT ab.date  FROM [dbo].[Absence] as ab WHERE ab.date between '" + day + "' AND '" + day2 + "' EXCEPT select Day(pi.date) from [punch-In] as pi where fname='" + combofname.Text + "' AND lname='" + combolname.Text + "' AND date BETWEEN '" + dpstart.Text + "'AND'" + dpend.Text + "'", con))

                            using (SqlDataReader dr = command1.ExecuteReader())
                            {

                                while (dr.Read())
                                {
                                    var diff = dr[0].ToString();

                                    lblabsence.Content += diff + ",";

                                }

                            }
                        }
                    }
                }
        }
            catch(Exception ex)
            {
                MyMessageBox.ShowBox(ex.ToString());
            }
}

    }
}





