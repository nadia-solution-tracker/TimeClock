﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AttendenceSystem
{
    /// <summary>
    /// Interaction logic for MyMessageBox.xaml
    /// </summary>
    public partial class MyMessageBox : Window
    {
        public MyMessageBox()
        {
            InitializeComponent();
        }
        static MyMessageBox newMessageBox;
        static string Button_id;
        public static string ShowBox(string txtMessage)
        {
            newMessageBox = new MyMessageBox();
            newMessageBox.lblmsg.Content = txtMessage;
           
            newMessageBox.ShowDialog();
            return Button_id;
        }

        public static string ShowBox(string txtMessage, string txtTitle)
        {
            newMessageBox = new MyMessageBox();
            newMessageBox.lblmsg.Content = txtMessage;
            newMessageBox.Title = txtTitle;
            newMessageBox.FontSize = 16;
            
            newMessageBox.ShowDialog();
            return Button_id;
        }

        private void btnok_Click(object sender, RoutedEventArgs e)
        {
            Button_id = "1";
            newMessageBox.Close();
        }

        private void btncancel_Click(object sender, RoutedEventArgs e)
        {
            newMessageBox.Close();
            Button_id = "2";
        }
    }
}
