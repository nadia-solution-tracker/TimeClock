﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AttendenceSystem
{
    /// <summary>
    /// Interaction logic for DeleteEmp.xaml
    /// </summary>
    public partial class DeleteEmp : Window
    {
        public DeleteEmp()
        {
            InitializeComponent();
            PopulateComboBoxFN();
        }
        private static string stringConn = ConfigurationManager.ConnectionStrings["AttendenceEntities"].ConnectionString;
        private void PopulateComboBoxFN()
        {

            using (SqlConnection sqlconn = new SqlConnection(stringConn))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = "SELECT fname FROM staff";
                    cmd.Connection = sqlconn;
                    sqlconn.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            this.comboFN.Items.Add((string)reader[0]);
                        }
                    }
                    sqlconn.Close();
                }
            }
        }

        private void comboFN_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (this.comboFN.SelectedIndex > -1)
            {
                this.comboLN.Items.Clear();
                string name = comboFN.SelectedItem.ToString();

                using (SqlConnection sqlconn = new SqlConnection(stringConn))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.CommandText = "SELECT lname FROM staff WHERE fname= @fName";
                        cmd.Parameters.Add("@fName", SqlDbType.VarChar, 50).Value = name;
                        cmd.Connection = sqlconn;
                        sqlconn.Open();
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                this.comboLN.Items.Add((string)reader[0]);

                            }
                            comboLN.SelectedIndex = 0;
                        }

                        sqlconn.Close();

                    }
                }
            }
        }

        private void comboLN_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var item = comboLN.SelectedItem as staff;
        }
        private void btndelete_Click(object sender, RoutedEventArgs e)
        {
            try {
                string ConString = ConfigurationManager.ConnectionStrings["AttendenceEntities"].ConnectionString;
                string CmdString = string.Empty;
                using (SqlConnection con = new SqlConnection(ConString))
                {
                    con.Open();
                    CmdString = "DELETE FROM staff  WHERE fname ='" + comboFN.Text + "' AND lname='" + comboLN.Text + "'";

                    SqlCommand cmd = new SqlCommand(CmdString, con);

                    var result = MessageBox.Show("Are you sure you want to delete this employee", "Confirmation", MessageBoxButton.YesNoCancel, MessageBoxImage.Question);
                    if (result == MessageBoxResult.Yes)
                    {
                        int nNoDeleted = cmd.ExecuteNonQuery();
                        MyMessageBox.ShowBox("'" + txtfname.Text + ' ' + txtlname.Text + "' Deleted", "Information");
                        con.Close();
                        txtfname.Clear();
                        txtlname.Clear();
                        comboDesig.SelectedIndex = 0;
                        txtpwd.Clear();
                        comboMIn.SelectedIndex = 0;
                        comboMOut.SelectedIndex = 0;
                        comboEIn.SelectedIndex = 0;
                        comboEOut.SelectedIndex = 0;
                        comboFN.SelectedIndex = -1;
                        comboLN.SelectedIndex = -1;
                        comboFN.Items.Clear();
                        PopulateComboBoxFN();
                    }
                    else if (result == MessageBoxResult.No)
                    {
                        MessageBox.Show("'" + txtfname.Text + ' ' + txtlname.Text + "' Not Deleted");

                    }

                }
            }
            catch(Exception ex)
            {
                MyMessageBox.ShowBox(ex.ToString());
            }
            }

        private void btnRecord_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if ((comboFN.SelectedIndex == -1) || (comboLN.SelectedIndex == -1))
                {
                    MyMessageBox.ShowBox("Fields cannot be empty!Select firstname from above", "Information");
                    return;
                }
                string ConString = ConfigurationManager.ConnectionStrings["AttendenceEntities"].ConnectionString;
                string Cmdstring = string.Empty;
                using (SqlConnection con = new SqlConnection(ConString))
                {
                    Cmdstring = "Select fname,lname,designation,password,FORMAT(CAST(MIn AS DATETIME),'HH:mm') AS MIn,FORMAT(CAST(MOut AS DATETIME),'HH:mm') AS MOut,FORMAT(CAST(EIn AS DATETIME),'HH:mm') AS EIn, FORMAT(CAST(EOut AS DATETIME),'HH:mm') AS EOut  from staff where fname='" + comboFN.Text + "' AND lname='" + comboLN.Text + "'";
                    // Cmdstring = "Select fname,lname,designation,password,CONVERT(VARCHAR(5),MIn, 108) AS MIn,CONVERT(VARCHAR(5),MOut, 108) AS MOut,CONVERT(VARCHAR(5),EIn, 108) AS EIn, CONVERT(VARCHAR(5),EOut, 108) AS EOut  from staff where fname='" + comboFN.Text + "' AND lname='" + comboLN.Text + "'";
                    SqlCommand cmd1 = new SqlCommand(Cmdstring, con);
                    SqlDataAdapter sda1 = new SqlDataAdapter(cmd1);
                    DataTable dt1 = new DataTable("staff");
                    sda1.Fill(dt1);
                    txtfname.Text = dt1.DefaultView[0]["fname"].ToString();
                    txtlname.Text = dt1.DefaultView[0]["lname"].ToString();

                    comboDesig.Text = dt1.DefaultView[0]["designation"].ToString();
                    txtpwd.Text = dt1.DefaultView[0]["password"].ToString();

                    comboMIn.Text = dt1.DefaultView[0]["MIn"].ToString();
                    comboMOut.Text = dt1.DefaultView[0]["MOut"].ToString();
                    comboEIn.Text = dt1.DefaultView[0]["EIn"].ToString();
                    comboEOut.Text = dt1.DefaultView[0]["EOut"].ToString();
                    if (comboDesig.Text != "Admin")
                    {
                        comboEIn.IsEnabled = true;
                        comboEOut.IsEnabled = true;
                    }
                }
            }
            catch(Exception ex)
            {
                MyMessageBox.ShowBox(ex.ToString());
            }
        }

        private void btnmenu_Click(object sender, RoutedEventArgs e)
        {
            Admin ad = new Admin();
            ad.Show();
            this.Close();
        }

        private void comboDesig_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (this.comboDesig.SelectedIndex > 2)
            {
                comboEIn.IsEnabled = false;
                comboEOut.IsEnabled = false;
            }
        }
    }
}
