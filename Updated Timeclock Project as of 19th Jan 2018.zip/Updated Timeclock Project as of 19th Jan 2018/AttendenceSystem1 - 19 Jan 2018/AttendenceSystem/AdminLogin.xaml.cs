﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AttendenceSystem
{
    /// <summary>
    /// Interaction logic for AdminLogin.xaml
    /// </summary>
    public partial class AdminLogin : Window
    {
        public AdminLogin()
        {
            InitializeComponent();
        }
        private static string stringConn = ConfigurationManager.ConnectionStrings["AttendenceEntities"].ConnectionString;
        
        private void btnlogin_Click(object sender, RoutedEventArgs e)
        {
            DataSet ds = new DataSet();
            using (SqlConnection connection = new SqlConnection(stringConn))

            using (SqlCommand command = new SqlCommand("select fname,lname,password from staff where fname='"+txtUN.Text+"' AND lname='"+txtUN.Text+"' AND password='" + passwordBox.Password + "'", connection))

            using (SqlDataAdapter adapter = new SqlDataAdapter(command))

            {

                adapter.Fill(ds);
               
            }
            if (ds.Tables[0].Rows.Count == 0)
            {
                MyMessageBox.ShowBox("Invalid Username or Password","Information");

            }
            else
            {
                Admin ad = new Admin();
                ad.Show();
                this.Close();
            }
        }

        private void btnpre_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();
        }

        private void btntime_Click(object sender, RoutedEventArgs e)
        {
            Time t = new Time();
            t.Show();
            this.Close();
        }
    }
}
