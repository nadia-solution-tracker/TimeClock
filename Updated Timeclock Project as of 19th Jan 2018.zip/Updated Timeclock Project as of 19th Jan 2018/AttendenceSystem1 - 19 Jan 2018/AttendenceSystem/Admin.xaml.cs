﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


namespace AttendenceSystem
{
    /// <summary>
    /// Interaction logic for Admin.xaml
    /// </summary>
    public partial class Admin : Window
    {
        public Admin()
        {
            InitializeComponent();
           
            
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            AddEmp ae = new AddEmp();
            ae.Show();
            this.Close();
            
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            DeleteEmp de = new DeleteEmp();
            de.Show();
            this.Close();
           
        }

        //private void btnRecord_Click(object sender, RoutedEventArgs e)
        //{
        //    //string ConString = ConfigurationManager.ConnectionStrings["AttendenceEntities"].ConnectionString;
        //    //string Cmdstring = string.Empty;
        //    //using (SqlConnection con = new SqlConnection(ConString))
        //    //{
        //    //     Cmdstring = "Select fname,lname,designation,password,FORMAT(CAST(MIn AS DATETIME),'HH:mm') AS MIn,FORMAT(CAST(MOut AS DATETIME),'HH:mm') AS MOut,FORMAT(CAST(EIn AS DATETIME),'HH:mm') AS EIn, FORMAT(CAST(EOut AS DATETIME),'HH:mm') AS EOut  from staff where fname='" + comboFN.Text + "' AND lname='" + comboLN.Text + "'";
        //    //   // Cmdstring = "Select fname,lname,designation,password,CONVERT(VARCHAR(5),MIn, 108) AS MIn,CONVERT(VARCHAR(5),MOut, 108) AS MOut,CONVERT(VARCHAR(5),EIn, 108) AS EIn, CONVERT(VARCHAR(5),EOut, 108) AS EOut  from staff where fname='" + comboFN.Text + "' AND lname='" + comboLN.Text + "'";
        //    //    SqlCommand cmd1 = new SqlCommand(Cmdstring, con);
        //    //    SqlDataAdapter sda1 = new SqlDataAdapter(cmd1);
        //    //    DataTable dt1 = new DataTable("staff");
        //    //    sda1.Fill(dt1);
        //    //    txtfname.Text = dt1.DefaultView[0]["fname"].ToString();
        //    //    txtlname.Text = dt1.DefaultView[0]["lname"].ToString();
               
        //    //    comboDesig.Text= dt1.DefaultView[0]["designation"].ToString();
        //    //    txtpwd.Text = dt1.DefaultView[0]["password"].ToString();
               
        //    //    comboMIn.Text = dt1.DefaultView[0]["MIn"].ToString();
        //    //    comboMOut.Text = dt1.DefaultView[0]["MOut"].ToString();
        //    //    comboEIn.Text = dt1.DefaultView[0]["EIn"].ToString();
        //    //    comboEOut.Text = dt1.DefaultView[0]["EOut"].ToString();
        //    //}
        //}

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            updateEmp ue = new updateEmp();
            ue.Show();
            this.Close();
           
        }

        private void btnlogout_Click(object sender, RoutedEventArgs e)
        {
            AdminLogin al = new AdminLogin();
            al.Show();
            this.Close();
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            Search se = new Search();
            se.Show();
            this.Close();
        }
    }
}
