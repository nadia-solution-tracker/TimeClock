﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Globalization;

namespace AttendenceSystem
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            PopulateComboBox();
        }

        private static string stringConn = ConfigurationManager.ConnectionStrings["AttendenceEntities"].ConnectionString;
        private void PopulateComboBox()
        {

            using (SqlConnection sqlconn = new SqlConnection(stringConn))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = "SELECT fname FROM staff";
                    cmd.Connection = sqlconn;
                    sqlconn.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            this.comboBox.Items.Add((string)reader[0]);
                        }
                    }
                    sqlconn.Close();
                }
            }
        }




        private void btnIn_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                DataSet ds = new DataSet();
                using (SqlConnection connection = new SqlConnection(stringConn))

                using (SqlCommand command = new SqlCommand("select * from staff where fname='" + comboBox.Text + "' AND lname='" + comboBox1.Text + "' AND password='" + passwordBox.Password + "'", connection))

                using (SqlDataAdapter adapter = new SqlDataAdapter(command))

                {

                    adapter.Fill(ds);
                    if (ds.Tables[0].Rows.Count == 0)
                    {

                        MyMessageBox.ShowBox("Invalid Username or Password!", "Information");
                        comboBox.SelectedIndex = -1;
                        comboBox1.SelectedIndex = -1;
                        passwordBox.Password = null;
                        return;
                    }



                }


                DateTime time = DateTime.Now;
                DateTime date = DateTime.Now;
                var First = ds.Tables[0].Rows[0]["MIn"].ToString();
                var Second = ds.Tables[0].Rows[0]["MOut"].ToString();
                var third = ds.Tables[0].Rows[0]["EIn"].ToString();
                var fourth = ds.Tables[0].Rows[0]["EOut"].ToString();
                DateTime start = new DateTime();
                start = DateTime.Parse(First);
                DateTime end = new DateTime();
                end = DateTime.Parse(Second);
                DateTime start1 = new DateTime();
                start1 = DateTime.Parse(third);
                DateTime end1 = new DateTime();
                end1 = DateTime.Parse(fourth);
                if (start < end)
                {
                    if (time >= start && time <= end)
                    {

                        DataSet ds1 = new DataSet();

                        using (SqlConnection connection1 = new SqlConnection(stringConn))

                        using (SqlCommand command = new SqlCommand("select date from [punch-In] where fname='" + comboBox.Text + "' AND lname='" + comboBox1.Text + "'AND date='" + date.ToString() + "'", connection1))

                        using (SqlDataAdapter adapter = new SqlDataAdapter(command))

                        {

                            adapter.Fill(ds1);
                            if (ds1.Tables[0].Rows.Count != 0)
                            {

                                DateTime date1 = DateTime.Now;
                                var Dat = ds1.Tables[0].Rows[0]["date"].ToString();
                                DateTime da = new DateTime();
                                da = DateTime.Parse(Dat);




                                using (SqlCommand command1 = new SqlCommand("select MIn FROM [punch-In] where fname='" + comboBox.Text + "' AND lname='" + comboBox1.Text + "' AND date='" + date.ToString() + "'", connection1))

                                using (SqlDataAdapter adapter1 = new SqlDataAdapter(command))

                                {

                                    adapter1.Fill(ds1);
                                    if (ds1.Tables[0].Rows.Count > 1)

                                    {
                                        if (da.ToString() != DateTime.Now.ToString())
                                        {

                                            MyMessageBox.ShowBox("Already Punched-In!", "Information");
                                            comboBox.SelectedIndex = -1;
                                            comboBox1.SelectedIndex = -1;
                                            passwordBox.Password = null;
                                            return;

                                        }
                                    }



                                }

                            }


                            SqlConnection connection = new SqlConnection(stringConn);
                            SqlCommand cmd = new SqlCommand("INSERT INTO [punch-In] (fname,lname,date,MIn,EIn) VALUES ('" + comboBox.SelectedValue + "','" + comboBox1.SelectedValue + "','" + date.ToString() + "', '" + time.ToString() + "', '" + null + "')", connection);
                            connection.Open();
                            cmd.ExecuteNonQuery();

                            SqlCommand cm = new SqlCommand("select CONCAT((DATEDIFF(Minute,st.MIn,pi.MIn)/60),':',(DATEDIFF(Minute, st.MIn, pi.MIn) % 60))DIFF FROM staff as st JOIN [punch-In] as pi ON st.fname=pi.fname AND st.lname=pi.lname WHERE pi.MIn='" + time.ToString() + "'", connection);
                            using (SqlDataReader dr = cm.ExecuteReader())
                            {
                                while (dr.Read())
                                {
                                    var diff = dr[0].ToString();
                                    DateTime d = new DateTime();
                                    d = DateTime.Parse(diff);

                                    DateTime comp = new DateTime();
                                    if (d > comp)
                                    {

                                        MyMessageBox.ShowBox("Successfully Punched-In,Late By " + diff + " Minutes", "Information");
                                    }
                                    else
                                    {
                                        MyMessageBox.ShowBox("Successfully Punched-In", "Information");
                                    }

                                }

                            }
                            comboBox.SelectedIndex = -1;
                            comboBox1.SelectedIndex = -1;
                            passwordBox.Password = null;
                            return;
                        }
                    }

                    else if (time < start)
                    {
                        DataSet ds1 = new DataSet();

                        using (SqlConnection connection1 = new SqlConnection(stringConn))

                        using (SqlCommand command = new SqlCommand("select date from [punch-In] where fname='" + comboBox.Text + "' AND lname='" + comboBox1.Text + "'AND date='" + date.ToString() + "'", connection1))

                        using (SqlDataAdapter adapter = new SqlDataAdapter(command))

                        {

                            adapter.Fill(ds1);
                            if (ds1.Tables[0].Rows.Count != 0)
                            {

                                DateTime date1 = DateTime.Now;
                                var Dat = ds1.Tables[0].Rows[0]["date"].ToString();
                                DateTime da = new DateTime();
                                da = DateTime.Parse(Dat);




                                using (SqlCommand command1 = new SqlCommand("select MIn FROM [punch-In] where fname='" + comboBox.Text + "' AND lname='" + comboBox1.Text + "' AND date='" + date.ToString() + "'", connection1))

                                using (SqlDataAdapter adapter1 = new SqlDataAdapter(command))

                                {

                                    adapter1.Fill(ds);
                                    if (ds.Tables[0].Rows.Count > 1)

                                    {
                                        if (da.ToString() != DateTime.Now.ToString())
                                        {

                                            MyMessageBox.ShowBox("Already Punched-In!", "Information");
                                            comboBox.SelectedIndex = -1;
                                            comboBox1.SelectedIndex = -1;
                                            passwordBox.Password = null;
                                            return;

                                        }
                                    }



                                }

                            }
                        }



                        SqlConnection connection = new SqlConnection(stringConn);
                        SqlCommand cmd = new SqlCommand("INSERT INTO [punch-In] (fname,lname,date,MIn,EIn) VALUES ('" + comboBox.SelectedValue + "','" + comboBox1.SelectedValue + "','" + date.ToString() + "', '" + time.ToString() + "', '" + null + "')", connection);
                        connection.Open();
                        cmd.ExecuteNonQuery();

                        //SqlCommand cm = new SqlCommand("select CONCAT((DATEDIFF(Minute,pi.MIn,st.MIn)/60),':',(DATEDIFF(Minute, pi.MIn, st.MIn) % 60))DIFF FROM staff as st JOIN [punch-In] as pi ON st.fname=pi.fname AND st.lname=pi.lname WHERE pi.MIn='" + time.ToString() + "'", connection);
                        //using (SqlDataReader dr = cm.ExecuteReader())
                        //{
                        //    while (dr.Read())
                        //    {
                        //        var diff = dr[0].ToString();
                        //        DateTime d = new DateTime();
                        //        d = DateTime.Parse(diff);

                        //        DateTime comp = new DateTime();
                        //        if (d > comp)
                        //        {

                        MyMessageBox.ShowBox("Successfully Punched-In", "Information");
                        //    }
                        //    else
                        //    {
                        //        MyMessageBox.ShowBox("Successfully Punched-In", "Information");
                        //    }

                        //}

                        //}
                        comboBox.SelectedIndex = -1;
                        comboBox1.SelectedIndex = -1;
                        passwordBox.Password = null;
                        return;
                    }
                }
                if (start1 < end1)
                {
                    if (time >= start1 && time <= end1)
                    {
                        DataSet ds1 = new DataSet();

                        using (SqlConnection connection1 = new SqlConnection(stringConn))

                        using (SqlCommand command = new SqlCommand("select date from [punch-In] where fname='" + comboBox.Text + "' AND lname='" + comboBox1.Text + "'AND date='" + date.ToString() + "' OR MIn='" + 00 + ':' + 00 + "' AND MIn!='" + 00 + ':' + 00 + "'", connection1))
                        {
                            using (SqlDataAdapter adapter = new SqlDataAdapter(command))

                            {

                                adapter.Fill(ds1);
                                if (ds1.Tables[0].Rows.Count != 0)
                                {


                                    DateTime date1 = DateTime.Now;
                                    var Dat = ds1.Tables[0].Rows[0]["date"].ToString();
                                    DateTime da = new DateTime();
                                    da = DateTime.Parse(Dat);



                                    using (SqlCommand command1 = new SqlCommand("select EIn FROM [punch-In] where fname='" + comboBox.Text + "' AND lname='" + comboBox1.Text + "' AND date='" + date.ToString() + "' AND EIn!='" + 00 + ':' + 00 + "'", connection1))


                                    using (SqlDataAdapter adapter1 = new SqlDataAdapter(command1))

                                    {

                                        adapter1.Fill(ds);
                                        if ((ds.Tables[0].Rows.Count > 1))

                                        {
                                            if (da.ToString() != DateTime.Now.ToString())
                                            {

                                                MyMessageBox.ShowBox("Already Punched-In", "Information");
                                                comboBox.SelectedIndex = -1;
                                                comboBox1.SelectedIndex = -1;
                                                passwordBox.Password = null;
                                                return;
                                            }

                                        }


                                    }

                                }


                                if (ds1.Tables[0].Rows.Count == 0)
                                {
                                    SqlConnection connection = new SqlConnection(stringConn);

                                    SqlCommand cmd = new SqlCommand("INSERT INTO [punch-In] (fname,lname,date,MIn,EIn) VALUES ('" + comboBox.SelectedValue + "','" + comboBox1.SelectedValue + "','" + date.ToString() + "', '" + null + "','" + time.ToString() + "')", connection);
                                    connection.Open();
                                    cmd.ExecuteNonQuery();


                                    SqlCommand cm = new SqlCommand("select CONCAT((DATEDIFF(Minute,st.EIn,pi.EIn)/60),':',(DATEDIFF(Minute, st.EIn, pi.EIn) % 60))DIFF FROM staff as st JOIN [punch-In] as pi ON st.fname=pi.fname AND st.lname=pi.lname WHERE pi.fname='" + comboBox.SelectedValue + "' AND pi.lname='" + comboBox1.SelectedValue + "' AND pi.EIn='" + time.ToString() + "'", connection);
                                    using (SqlDataReader dr = cm.ExecuteReader())
                                    {
                                        while (dr.Read())
                                        {
                                            var diff = dr[0].ToString();
                                            DateTime d = new DateTime();
                                            d = DateTime.Parse(diff);

                                            DateTime comp = new DateTime();
                                            if (d > comp)
                                            {

                                                MyMessageBox.ShowBox("Successfully Punched-In! late by" + diff + " Minutes", "Information");
                                            }
                                            else
                                            {
                                                MyMessageBox.ShowBox("Successfully Punched-In !", "Information");
                                            }

                                            connection1.Close();

                                        }
                                    }

                                    comboBox.SelectedIndex = -1;
                                    comboBox1.SelectedIndex = -1;
                                    passwordBox.Password = null;
                                    return;
                                }
                            }
                        }



                        SqlConnection connection5 = new SqlConnection(stringConn);

                        SqlCommand command5 = new SqlCommand("select date from [punch-In] where fname='" + comboBox.Text + "' AND lname='" + comboBox1.Text + "' AND MIn!='" + 00 + ':' + 00 + "'", connection5);

                        SqlDataAdapter adapter5 = new SqlDataAdapter(command5);

                        adapter5.Fill(ds1);
                        if (ds1.Tables[0].Rows.Count != 0)
                        {

                            DateTime date1 = DateTime.Now;
                            var Dat = ds1.Tables[0].Rows[0]["date"].ToString();
                            DateTime da = new DateTime();
                            da = DateTime.Parse(Dat);



                            using (SqlCommand command6 = new SqlCommand("select EIn FROM [punch-In] where fname='" + comboBox.Text + "' AND lname='" + comboBox1.Text + "' AND date='" + date.ToString() + "'AND MIn!='" + 00 + ':' + 00 + "' AND EIn!='" + 00 + ':' + 00 + "'", connection5))


                            using (SqlDataAdapter adapter6 = new SqlDataAdapter(command6))

                            {

                                adapter6.Fill(ds);
                                if ((ds.Tables[0].Rows.Count > 1))

                                {
                                    if (da.ToString() != DateTime.Now.ToString())
                                    {

                                        MyMessageBox.ShowBox("Already Punched-In", "Information");
                                        comboBox.SelectedIndex = -1;
                                        comboBox1.SelectedIndex = -1;
                                        passwordBox.Password = null;
                                        return;
                                    }

                                }


                            }





                            SqlConnection connection = new SqlConnection(stringConn);
                            SqlCommand cmd = new SqlCommand("UPDATE [punch-In] SET EIn ='" + time.ToString() + "' where MIn!='" + 00 + ':' + 00 + "' and fname='" + comboBox.Text + "' AND lname='" + comboBox1.Text + "' AND date='" + date.ToString() + "'", connection);
                            connection.Open();
                            cmd.ExecuteNonQuery();


                            SqlCommand cm = new SqlCommand("select CONCAT((DATEDIFF(Minute,st.EIn,pi.EIn)/60),':',(DATEDIFF(Minute, st.EIn, pi.EIn) % 60))DIFF FROM staff as st JOIN [punch-In] as pi ON st.fname=pi.fname AND st.lname=pi.lname WHERE pi.fname='" + comboBox.SelectedValue + "' AND pi.lname='" + comboBox1.SelectedValue + "' AND pi.EIn='" + time.ToString() + "'", connection);
                            using (SqlDataReader dr = cm.ExecuteReader())
                            {
                                while (dr.Read())
                                {
                                    var diff = dr[0].ToString();
                                    DateTime d = new DateTime();
                                    d = DateTime.Parse(diff);

                                    DateTime comp = new DateTime();
                                    if (d > comp)
                                    {

                                        MyMessageBox.ShowBox("Successfully Punched-In! late by" + diff + " Minutes", "Information");
                                    }
                                    else
                                    {
                                        MyMessageBox.ShowBox("Successfully Punched-In !", "Information");
                                    }


                                    comboBox.SelectedIndex = -1;
                                    comboBox1.SelectedIndex = -1;
                                    passwordBox.Password = null;
                                    return;
                                }
                            }
                        }




                    }







                    if (time < start1)
                    {
                        DataSet ds1 = new DataSet();

                        using (SqlConnection connection1 = new SqlConnection(stringConn))

                        using (SqlCommand command = new SqlCommand("select date from [punch-In] where fname='" + comboBox.Text + "' AND lname='" + comboBox1.Text + "'AND date='" + date.ToString() + "'and MIn!='" + 00 + ':' + 00 + "'", connection1))

                        using (SqlDataAdapter adapter = new SqlDataAdapter(command))

                        {

                            adapter.Fill(ds1);
                            if (ds1.Tables[0].Rows.Count != 0)
                            {


                                DateTime date1 = DateTime.Now;
                                var Dat = ds1.Tables[0].Rows[0]["date"].ToString();
                                DateTime da = new DateTime();
                                da = DateTime.Parse(Dat);



                                using (SqlCommand command1 = new SqlCommand("select EIn FROM [punch-In] where fname='" + comboBox.Text + "' AND lname='" + comboBox1.Text + "' AND date='" + date.ToString() + "'and EIn!='" + 00 + ':' + 00 + "'", connection1))


                                using (SqlDataAdapter adapter1 = new SqlDataAdapter(command1))

                                {

                                    adapter1.Fill(ds);
                                    if (ds.Tables[0].Rows.Count > 1)

                                    {
                                        if (da.ToString() != DateTime.Now.ToString())
                                        {

                                            MyMessageBox.ShowBox("Already Punched-In", "Information");
                                            comboBox.SelectedIndex = -1;
                                            comboBox1.SelectedIndex = -1;
                                            passwordBox.Password = null;
                                            return;
                                        }

                                    }



                                }

                            }
                            if (ds1.Tables[0].Rows.Count == 0)
                            {
                                SqlConnection connection = new SqlConnection(stringConn);
                                SqlCommand cmd = new SqlCommand("INSERT INTO [punch-In] (fname,lname,date,MIn,EIn) VALUES ('" + comboBox.SelectedValue + "','" + comboBox1.SelectedValue + "','" + date.ToString() + "', '" + null + "','" + time.ToString() + "')", connection);
                                connection.Open();
                                cmd.ExecuteNonQuery();


                                //SqlCommand cm = new SqlCommand("select CONCAT((DATEDIFF(Minute,st.EIn,pi.EIn)/60),':',(DATEDIFF(Minute, st.EIn, pi.EIn) % 60))DIFF FROM staff as st JOIN [punch-In] as pi ON st.fname=pi.fname AND st.lname=pi.lname WHERE pi.fname='" + comboBox.SelectedValue + "' AND pi.lname='" + comboBox1.SelectedValue + "' AND pi.EIn='" + time.ToString() + "'", connection);
                                //using (SqlDataReader dr = cm.ExecuteReader())
                                //{
                                //    while (dr.Read())
                                //    {
                                //        var diff = dr[0].ToString();
                                //        DateTime d = new DateTime();
                                //        d = DateTime.Parse(diff);

                                //        DateTime comp = new DateTime();
                                //        if (d > comp)
                                //        {

                                MyMessageBox.ShowBox("Successfully Punched-In!", "Information");
                                //        }
                                //        else
                                //        {
                                //            MyMessageBox.ShowBox("Successfully Punched-In !", "Information");
                                //        }
                                //    }
                                //}
                                connection1.Close();
                                comboBox.SelectedIndex = -1;
                                comboBox1.SelectedIndex = -1;
                                passwordBox.Password = null;
                                return;
                            }
                        }




                        SqlConnection connection5 = new SqlConnection(stringConn);

                        SqlCommand command5 = new SqlCommand("select date from [punch-In] where fname='" + comboBox.Text + "' AND lname='" + comboBox1.Text + "' AND MIn!='" + 00 + ':' + 00 + "'", connection5);

                        SqlDataAdapter adapter5 = new SqlDataAdapter(command5);

                        adapter5.Fill(ds1);
                        if (ds1.Tables[0].Rows.Count != 0)
                        {
                            DateTime date1 = DateTime.Now;
                            var Dat = ds1.Tables[0].Rows[0]["date"].ToString();
                            DateTime da = new DateTime();
                            da = DateTime.Parse(Dat);



                            using (SqlCommand command1 = new SqlCommand("select EIn FROM [punch-In] where fname='" + comboBox.Text + "' AND lname='" + comboBox1.Text + "' AND date='" + date.ToString() + "'and EIn!='" + 00 + ':' + 00 + "'", connection5))


                            using (SqlDataAdapter adapter1 = new SqlDataAdapter(command1))

                            {

                                adapter1.Fill(ds);
                                if (ds.Tables[0].Rows.Count > 1)

                                {
                                    if (da.ToString() != DateTime.Now.ToString())
                                    {

                                        MyMessageBox.ShowBox("Already Punched-In", "Information");
                                        comboBox.SelectedIndex = -1;
                                        comboBox1.SelectedIndex = -1;
                                        passwordBox.Password = null;
                                        return;
                                    }

                                }



                            }



                            SqlConnection connection = new SqlConnection(stringConn);
                            SqlCommand cmd = new SqlCommand("UPDATE [punch-In] SET EIn ='" + time.ToString() + "' where MIn!='" + 00 + ':' + 00 + "'and fname='" + comboBox.Text + "' AND lname='" + comboBox1.Text + "' AND date='" + date.ToString() + "'", connection);
                            connection.Open();
                            cmd.ExecuteNonQuery();


                            //SqlCommand cm = new SqlCommand("select CONCAT((DATEDIFF(Minute,st.EIn,pi.EIn)/60),':',(DATEDIFF(Minute, st.EIn, pi.EIn) % 60))DIFF FROM staff as st JOIN [punch-In] as pi ON st.fname=pi.fname AND st.lname=pi.lname WHERE pi.fname='" + comboBox.SelectedValue + "' AND pi.lname='" + comboBox1.SelectedValue + "' AND pi.EIn='" + time.ToString() + "'", connection);
                            //using (SqlDataReader dr = cm.ExecuteReader())
                            //{
                            //    while (dr.Read())
                            //    {
                            //        var diff = dr[0].ToString();
                            //        DateTime d = new DateTime();
                            //        d = DateTime.Parse(diff);

                            //        DateTime comp = new DateTime();
                            //        if (d > comp)
                            //        {

                            MyMessageBox.ShowBox("Successfully Punched-In!", "Information");
                            //        }
                            //        else
                            //        {
                            //            MyMessageBox.ShowBox("Successfully Punched-In !", "Information");
                            //        }
                            //    }
                            //}
                            comboBox.SelectedIndex = -1;
                            comboBox1.SelectedIndex = -1;
                            passwordBox.Password = null;
                            return;

                        }
                    }


                }






                Time pre = new Time();
                pre.Show();
                this.Close();
            
            
            }

            catch (Exception ex)
            {
                MyMessageBox.ShowBox(ex.ToString());
            }
            }


        private void btnOut_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                DataSet ds = new DataSet();

                using (SqlConnection connection = new SqlConnection(stringConn))
                using (SqlCommand command = new SqlCommand("select * from staff where fname='" + comboBox.Text + "' AND lname='" + comboBox1.Text + "'AND password='" + passwordBox.Password + "'", connection))
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    adapter.Fill(ds);
                    if (ds.Tables[0].Rows.Count == 0)
                    {
                        MyMessageBox.ShowBox("Invalid Username or Password,Please Try Again !", "Information");
                        comboBox.SelectedIndex = -1;
                        comboBox1.SelectedIndex = -1;
                        passwordBox.Password = null;
                        return;
                    }

                }

                DateTime time = DateTime.Now;

                DateTime date = DateTime.Now;
                var First = ds.Tables[0].Rows[0]["MIn"].ToString();
                var Second = ds.Tables[0].Rows[0]["MOut"].ToString();
                var third = ds.Tables[0].Rows[0]["EIn"].ToString();
                var fourth = ds.Tables[0].Rows[0]["EOut"].ToString();
                DateTime start = new DateTime();
                start = DateTime.Parse(First);
                DateTime end = new DateTime();
                end = DateTime.Parse(Second);
                DateTime start1 = new DateTime();
                start1 = DateTime.Parse(third);
                DateTime end1 = new DateTime();
                end1 = DateTime.Parse(fourth);
                if (end > start)
                {

                    if (time >= start && time <= end)
                    {
                        DataSet ds1 = new DataSet();

                        using (SqlConnection connection1 = new SqlConnection(stringConn))

                        using (SqlCommand command = new SqlCommand("select date from [punch-Out] where fname='" + comboBox.Text + "' AND lname='" + comboBox1.Text + "'AND date='" + date.ToString() + "'", connection1))

                        using (SqlDataAdapter adapter = new SqlDataAdapter(command))

                        {

                            adapter.Fill(ds1);
                            if (ds1.Tables[0].Rows.Count != 0)
                            {


                                DateTime date1 = DateTime.Now;
                                var Dat = ds1.Tables[0].Rows[0]["date"].ToString();
                                DateTime da = new DateTime();
                                da = DateTime.Parse(Dat);




                                using (SqlCommand command1 = new SqlCommand("select MOut FROM [punch-Out] where fname='" + comboBox.Text + "' AND lname='" + comboBox1.Text + "'AND date='" + date.ToString() + "'", connection1))

                                using (SqlDataAdapter adapter1 = new SqlDataAdapter(command1))

                                {

                                    adapter1.Fill(ds);
                                    if (ds.Tables[0].Rows.Count > 1)

                                    {
                                        if (da.ToString() != DateTime.Now.ToString())
                                        {
                                            MyMessageBox.ShowBox("Already Punched-Out!", "Information");
                                            comboBox.SelectedIndex = -1;
                                            comboBox1.SelectedIndex = -1;
                                            passwordBox.Password = null;
                                            return;
                                        }

                                    }



                                }
                            }
                        }
                        DataSet ds2 = new DataSet();
                        SqlConnection connection = new SqlConnection(stringConn);
                        SqlCommand cmd1 = new SqlCommand("select MIn from [punch-In] where fname='" + comboBox.Text + "' AND lname='" + comboBox1.Text + "' AND date='" + date.ToString() + "'", connection);
                        using (SqlDataAdapter adapter = new SqlDataAdapter(cmd1))

                        {

                            adapter.Fill(ds2);
                            if (ds2.Tables[0].Rows.Count > 0)
                            {

                                SqlCommand cmd = new SqlCommand("INSERT INTO [punch-Out] (fname,lname,date,MOut,EOut) VALUES ('" + comboBox.SelectedValue + "','" + comboBox1.SelectedValue + "','" + date.ToString() + "', '" + time.ToString() + "','" + null + "')", connection);
                                connection.Open();
                                int added = cmd.ExecuteNonQuery();




                                SqlCommand cm = new SqlCommand("select CONCAT((DATEDIFF(Minute,po.MOut,st.MOut)/60),':',(DATEDIFF(Minute, po.MOut, st.MOut) % 60))DIFF FROM staff as st JOIN [punch-Out] as po ON st.fname=po.fname AND st.lname=po.lname WHERE po.MOut='" + time.ToString() + "'", connection);
                                using (SqlDataReader dr = cm.ExecuteReader())
                                {
                                    while (dr.Read())
                                    {
                                        var diff = dr[0].ToString();
                                        DateTime d = new DateTime();
                                        d = DateTime.Parse(diff);

                                        DateTime comp = new DateTime();
                                        if (d > comp)
                                        {
                                            MyMessageBox.ShowBox("Successfully Punched-Out!", "Information");
                                        }
                                        else
                                        {
                                            MyMessageBox.ShowBox("Successfully Punched-Out!", "Information");
                                        }

                                    }
                                }
                                comboBox.SelectedIndex = -1;
                                comboBox1.SelectedIndex = -1;
                                passwordBox.Password = null;
                                return;
                            }
                            else
                            {
                                MyMessageBox.ShowBox("Please Punch-In First!", "Information");
                                comboBox.SelectedIndex = -1;
                                comboBox1.SelectedIndex = -1;
                                passwordBox.Password = null;
                                return;
                            }
                        }
                    }

                        DataSet ds3 = new DataSet();
                        SqlConnection connection3 = new SqlConnection(stringConn);
                        SqlCommand cmd3 = new SqlCommand("select EIn from [punch-In] where fname='" + comboBox.Text + "' AND lname='" + comboBox1.Text + "' AND date='" + date.ToString() + "' AND EIn='" + 00 + ':' + 00 + "'", connection3);

                        SqlDataAdapter adapter3 = new SqlDataAdapter(cmd3);
                        adapter3.Fill(ds3);
                        if ((time > end && (ds3.Tables[0].Rows.Count == 1)) || time < start)
                        {
                            DataSet ds1 = new DataSet();

                            using (SqlConnection connection1 = new SqlConnection(stringConn))

                            using (SqlCommand command = new SqlCommand("select date from [punch-Out] where fname='" + comboBox.Text + "' AND lname='" + comboBox1.Text + "'AND date='" + date.ToString() + "'", connection1))

                            using (SqlDataAdapter adapter = new SqlDataAdapter(command))

                            {

                                adapter.Fill(ds1);
                                if (ds1.Tables[0].Rows.Count != 0)
                                {


                                    DateTime date1 = DateTime.Now;
                                    var Dat = ds1.Tables[0].Rows[0]["date"].ToString();
                                    DateTime da = new DateTime();
                                    da = DateTime.Parse(Dat);



                                    using (SqlCommand command1 = new SqlCommand("select MOut FROM [punch-Out] where fname='" + comboBox.Text + "' AND lname='" + comboBox1.Text + "'AND date='" + date.ToString() + "'", connection1))

                                    using (SqlDataAdapter adapter1 = new SqlDataAdapter(command1))

                                    {

                                        adapter1.Fill(ds);
                                        if (ds.Tables[0].Rows.Count > 1)

                                        {
                                            if (da.ToString() != DateTime.Now.ToString())
                                            {
                                                MyMessageBox.ShowBox("Already Punched-Out!", "Information");
                                                comboBox.SelectedIndex = -1;
                                                comboBox1.SelectedIndex = -1;
                                                passwordBox.Password = null;
                                                return;
                                            }

                                        }



                                    }
                                }
                                connection1.Close();
                            }
                            connection3.Close();


                            SqlConnection connection = new SqlConnection(stringConn);
                            SqlCommand cmd = new SqlCommand("INSERT INTO [punch-Out] (fname,lname,date,MOut,EOut) VALUES ('" + comboBox.SelectedValue + "','" + comboBox1.SelectedValue + "','" + date.ToString() + "', '" + time.ToString() + "','" + null + "')", connection);
                            connection.Open();
                            int added = cmd.ExecuteNonQuery();
                            MyMessageBox.ShowBox("Successfully Punched-Out!", "Information");
                            comboBox.SelectedIndex = -1;
                            comboBox1.SelectedIndex = -1;
                            passwordBox.Password = null;
                            return;
                        }
                    }
                

                if (end1 > start1)
                {


                    if (time >= start1 && time <= end1)
                    {
                        DataSet ds1 = new DataSet();

                        using (SqlConnection connection1 = new SqlConnection(stringConn))

                        using (SqlCommand command = new SqlCommand("select fname,lname,date from [punch-Out] where fname='" + comboBox.Text + "' AND lname='" + comboBox1.Text + "'OR MOut='" + 00 + ':' + 00 + "' AND MOut!='" + 00 + ':' + 00 + "'", connection1))
                        {
                            using (SqlDataAdapter adapter = new SqlDataAdapter(command))

                            {

                                adapter.Fill(ds1);
                                if (ds1.Tables[0].Rows.Count != 0)
                                {


                                    DateTime date1 = DateTime.Now;
                                    var Dat = ds1.Tables[0].Rows[0]["date"].ToString();
                                    DateTime da = new DateTime();
                                    da = DateTime.Parse(Dat);




                                    DataSet ds3 = new DataSet();

                                    using (SqlCommand command1 = new SqlCommand("select EOut FROM [punch-Out] where fname='" + comboBox.Text + "' AND lname='" + comboBox1.Text + "'AND date='" + date.ToString() + "'AND MOut='" + 00 + ':' + 00 + "'", connection1))

                                    using (SqlDataAdapter adapter1 = new SqlDataAdapter(command1))

                                    {

                                        adapter1.Fill(ds3);
                                        if (ds3.Tables[0].Rows.Count >= 1)

                                        {
                                            if (da.ToString() != DateTime.Now.ToString())
                                            {
                                                MyMessageBox.ShowBox("Already Punched-Out!", "Information");
                                                comboBox.SelectedIndex = -1;
                                                comboBox1.SelectedIndex = -1;
                                                passwordBox.Password = null;
                                                return;
                                            }

                                        }


                                    }
                                }

                                if (ds1.Tables[0].Rows.Count == 0)
                                {
                                    DataSet ds4 = new DataSet();
                                    SqlConnection connection4 = new SqlConnection(stringConn);


                                    SqlCommand cmd4 = new SqlCommand("select EIn from [punch-In] where fname='" + comboBox.Text + "' AND lname='" + comboBox1.Text + "' AND date='" + date.ToString() + "'", connection4);
                                    using (SqlDataAdapter adapter6 = new SqlDataAdapter(cmd4))

                                    {

                                        adapter6.Fill(ds4);
                                        if (ds4.Tables[0].Rows.Count == 1)
                                        {



                                            SqlCommand cmd = new SqlCommand("INSERT INTO [punch-Out] (fname,lname,date,MOut,EOut) VALUES ('" + comboBox.SelectedValue + "','" + comboBox1.SelectedValue + "','" + date.ToString() + "', '" + null + "','" + time.ToString() + "')", connection4);
                                            connection4.Open();
                                            int added = cmd.ExecuteNonQuery();


                                            SqlCommand cm = new SqlCommand("select CONCAT((DATEDIFF(Minute,po.EOut,st.EOut)/60),':',(DATEDIFF(Minute, po.EOut, st.EOut) % 60))DIFF FROM staff as st JOIN [punch-Out] as po ON st.fname=po.fname AND st.lname=po.lname WHERE po.fname='" + comboBox.SelectedValue + "' AND po.lname='" + comboBox1.SelectedValue + "' AND po.EOut='" + time.ToString() + "'", connection4);
                                            using (SqlDataReader dr = cm.ExecuteReader())
                                            {
                                                while (dr.Read())
                                                {
                                                    var diff = dr[0].ToString();
                                                    DateTime d = new DateTime();
                                                    d = DateTime.Parse(diff);

                                                    DateTime comp = new DateTime();
                                                    if (d > comp)
                                                    {
                                                        MyMessageBox.ShowBox("Successfully Punched-Out!", "Information");
                                                    }
                                                    else
                                                    {
                                                        MyMessageBox.ShowBox("Successfully Punched-Out!", "Information");
                                                    }
                                                    
                                                }
                                            }
                                            connection1.Close();
                                            comboBox.SelectedIndex = -1;
                                            comboBox1.SelectedIndex = -1;
                                            passwordBox.Password = null;
                                            return;
                                        }
                                    }

                                }
                            }
                        }
                        SqlConnection connection5 = new SqlConnection(stringConn);

                        SqlCommand command5 = new SqlCommand("select date from [punch-Out] where fname='" + comboBox.Text + "' AND lname='" + comboBox1.Text + "' AND MOut!='" + 00 + ':' + 00 + "'", connection5);

                        SqlDataAdapter adapter5 = new SqlDataAdapter(command5);

                        adapter5.Fill(ds1);

                        if (ds1.Tables[0].Rows.Count != 0)
                        {
                            DateTime date1 = DateTime.Now;
                            var Dat = ds1.Tables[0].Rows[0]["date"].ToString();
                            DateTime da = new DateTime();
                            da = DateTime.Parse(Dat);




                            DataSet ds3 = new DataSet();

                            using (SqlCommand command1 = new SqlCommand("select EOut FROM [punch-Out] where fname='" + comboBox.Text + "' AND lname='" + comboBox1.Text + "'AND date='" + date.ToString() + "'AND MOut!='" + 00 + ':' + 00 + "' AND EOut!='" + 00 + ':' + 00 + "'", connection5))

                            using (SqlDataAdapter adapter1 = new SqlDataAdapter(command1))

                            {

                                adapter1.Fill(ds3);
                                if (ds3.Tables[0].Rows.Count > 1)

                                {
                                    if (da.ToString() != DateTime.Now.ToString())
                                    {
                                        MyMessageBox.ShowBox("Already Punched-Out!", "Information");
                                        comboBox.SelectedIndex = -1;
                                        comboBox1.SelectedIndex = -1;
                                        passwordBox.Password = null;
                                        return;
                                    }

                                }


                            }
                        }

                        DataSet ds2 = new DataSet();
                        SqlConnection connection = new SqlConnection(stringConn);


                        SqlCommand cmd1 = new SqlCommand("select EIn from [punch-In] where fname='" + comboBox.Text + "' AND lname='" + comboBox1.Text + "' AND date='" + date.ToString() + "'", connection);
                        using (SqlDataAdapter adapter6 = new SqlDataAdapter(cmd1))

                        {

                            adapter6.Fill(ds2);
                            if (ds2.Tables[0].Rows.Count >= 1)
                            {



                                SqlCommand cmd = new SqlCommand("UPDATE [punch-Out] SET EOut ='" + time.ToString() + "' where MOut!='" + 00 + ':' + 00 + "'and fname='" + comboBox.Text + "' AND lname='" + comboBox1.Text + "' AND date='" + date.ToString() + "'", connection);
                                connection.Open();
                                int added = cmd.ExecuteNonQuery();


                                //SqlCommand cm = new SqlCommand("select CONCAT((DATEDIFF(Minute,po.EOut,st.EOut)/60),':',(DATEDIFF(Minute, po.EOut, st.EOut) % 60))DIFF FROM staff as st JOIN [punch-Out] as po ON st.fname=po.fname AND st.lname=po.lname WHERE po.fname='" + comboBox.SelectedValue + "' AND po.lname='" + comboBox1.SelectedValue + "' AND po.EOut='" + time.ToString() + "'", connection);
                                //using (SqlDataReader dr = cm.ExecuteReader())
                                //{
                                //    while (dr.Read())
                                //    {
                                //        var diff = dr[0].ToString();
                                //        DateTime d = new DateTime();
                                //        d = DateTime.Parse(diff);

                                //        DateTime comp = new DateTime();
                                //        if (d > comp)
                                //        {
                                //            MyMessageBox.ShowBox("Successfully Punched-Out!", "Information");
                                //        }
                                //        else
                                //        {
                                MyMessageBox.ShowBox("Successfully Punched-Out!", "Information");
                                //        }
                                //    }
                                //}
                                comboBox.SelectedIndex = -1;
                                comboBox1.SelectedIndex = -1;
                                passwordBox.Password = null;
                                return;
                            }
                        }
                    }
                    //else
                    //{
                    //    MyMessageBox.ShowBox("Please Punch-In First!", "Information");
                    //    comboBox.SelectedIndex = -1;
                    //    comboBox1.SelectedIndex = -1;
                    //    passwordBox.Password = null;
                    //    return;
                    //}
                        }


                    

                    if((time>end1)||(time<start1&&time<end1))
                    {
                        DataSet ds1 = new DataSet();

                    using (SqlConnection connection1 = new SqlConnection(stringConn))

                    using (SqlCommand command = new SqlCommand("select fname,lname,date from [punch-Out] where fname='" + comboBox.Text + "' AND lname='" + comboBox1.Text + "'AND MOut!='" + 00 + ':' + 00 + "'OR MOut='" + 00 + ':' + 00 + "'", connection1))

                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))

                    {

                        adapter.Fill(ds1);
                        if (ds1.Tables[0].Rows.Count != 0)
                        {


                            DateTime date1 = DateTime.Now;
                            var Dat = ds1.Tables[0].Rows[0]["date"].ToString();
                            DateTime da = new DateTime();
                            da = DateTime.Parse(Dat);





                            using (SqlCommand command1 = new SqlCommand("select EOut FROM [punch-Out] where fname='" + comboBox.Text + "' AND lname='" + comboBox1.Text + "'AND date='" + date.ToString() + "'AND MOut='" + 00 + ':' + 00 + "'", connection1))

                            using (SqlDataAdapter adapter1 = new SqlDataAdapter(command1))

                            {

                                adapter1.Fill(ds);
                                if (ds.Tables[0].Rows.Count > 1)

                                {
                                    if (da.ToString() != DateTime.Now.ToString())
                                    {
                                        MyMessageBox.ShowBox("Already Punched-Out!", "Information");
                                        comboBox.SelectedIndex = -1;
                                        comboBox1.SelectedIndex = -1;
                                        passwordBox.Password = null;
                                        return;
                                    }

                                }



                            }
                        }

                        if (ds1.Tables[0].Rows.Count == 0)
                        {

                            SqlConnection connection = new SqlConnection(stringConn);
                            SqlCommand cmd = new SqlCommand("INSERT INTO [punch-Out] (fname,lname,date,MOut,EOut) VALUES ('" + comboBox.SelectedValue + "','" + comboBox1.SelectedValue + "','" + date.ToString() + "', '" + null + "','" + time.ToString() + "')", connection);
                            connection.Open();
                            int added = cmd.ExecuteNonQuery();
                            MyMessageBox.ShowBox("Successfully Punched-Out!", "Information");
                            comboBox.SelectedIndex = -1;
                            comboBox1.SelectedIndex = -1;
                            passwordBox.Password = null;
                            return;
                        }
                    }
                        
                        SqlConnection connection5 = new SqlConnection(stringConn);

                        SqlCommand command5 = new SqlCommand("select date from [punch-Out] where fname='" + comboBox.Text + "' AND lname='" + comboBox1.Text + "' AND MOut!='" + 00 + ':' + 00 + "'", connection5);

                        SqlDataAdapter adapter5 = new SqlDataAdapter(command5);

                        adapter5.Fill(ds1);
                         if (ds1.Tables[0].Rows.Count != 0)
                            {

                                DateTime date1 = DateTime.Now;
                                var Dat = ds1.Tables[0].Rows[0]["date"].ToString();
                                DateTime da = new DateTime();
                                da = DateTime.Parse(Dat);





                                using (SqlCommand command1 = new SqlCommand("select EOut FROM [punch-Out] where fname='" + comboBox.Text + "' AND lname='" + comboBox1.Text + "'AND date='" + date.ToString() + "' and MOut!='" + 00 + ':' + 00 + "'and EOut!='" + 00 + ':' + 00 + "'", connection5))

                                using (SqlDataAdapter adapter1 = new SqlDataAdapter(command1))

                                {

                                    adapter1.Fill(ds);
                                    if (ds.Tables[0].Rows.Count > 1)

                                    {
                                        if (da.ToString() != DateTime.Now.ToString())
                                        {
                                            MyMessageBox.ShowBox("Already Punched-Out!", "Information");
                                            comboBox.SelectedIndex = -1;
                                            comboBox1.SelectedIndex = -1;
                                            passwordBox.Password = null;
                                            return;
                                        }

                                    }



                                }



                                SqlConnection connection = new SqlConnection(stringConn);
                                SqlCommand cmd = new SqlCommand("UPDATE [punch-Out] SET EOut ='" + time.ToString() + "' where MOut!='" + 00 + ':' + 00 + "'and fname='" + comboBox.Text + "' AND lname='" + comboBox1.Text + "' AND date='" + date.ToString() + "'", connection);
                                connection.Open();
                                int added = cmd.ExecuteNonQuery();
                                MyMessageBox.ShowBox("Successfully Punched-Out!", "Information");
                                comboBox.SelectedIndex = -1;
                                comboBox1.SelectedIndex = -1;
                                passwordBox.Password = null;
                                return;
                            }
                        }
                    

                

                Time pre = new Time();
                pre.Show();
                this.Close();
            }
            catch(Exception ex)
            {
                MyMessageBox.ShowBox(ex.ToString());
            }
            }


        private void comboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (this.comboBox.SelectedIndex > -1)
            {
                this.comboBox1.Items.Clear();
                string name = comboBox.SelectedItem.ToString();

                using (SqlConnection sqlconn = new SqlConnection(stringConn))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.CommandText = "SELECT lname FROM staff WHERE fname= @fName";
                        cmd.Parameters.Add("@fName", SqlDbType.VarChar, 50).Value = name;
                        cmd.Connection = sqlconn;
                        sqlconn.Open();
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                this.comboBox1.Items.Add((string)reader[0]);

                            }
                            comboBox1.SelectedIndex = 0;
                        }

                        sqlconn.Close();

                    }
                }
            }
        }




        private void comboBox1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var item = comboBox1.SelectedItem as staff;
        }

        private void btnAdmin_Click(object sender, RoutedEventArgs e)
        {
            AdminLogin win = new AdminLogin();
            win.Show();
            this.Close();
        }

        private void btnPrev_Click(object sender, RoutedEventArgs e)
        {
            Time pre = new Time();
            pre.Show();
            this.Close();
        }
    }
}


